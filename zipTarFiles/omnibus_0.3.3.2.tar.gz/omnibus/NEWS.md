omnibus 0.3.3.2 (2020-01-31)

Added function mirror() which returns mirror image of characters/numbers
Added function roundedFrom() which infers number of significant digits

omnibus 0.3.3.1 (2020-01-29)

Added function naCompare() for "NA-safe" comparative operations (>, >=, ==, !=, <, <=)
