omnibus 0.3.3.1 (2020-01-29)

Added function naCompare() for "NA-safe" comparative operations (>, >=, ==, !=, <, <=)