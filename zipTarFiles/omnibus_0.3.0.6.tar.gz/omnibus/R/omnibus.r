#' omnibus: Fantabulous helper functions
#'
#' This package contains a set of helper functions.
#'
#' Create an issue on \href{https://github.com/adamlilith/omnibus/issues}{GitHub}.
#'
#' @docType package
#' @author Adam B. Smith
#' @name omnibus
NULL